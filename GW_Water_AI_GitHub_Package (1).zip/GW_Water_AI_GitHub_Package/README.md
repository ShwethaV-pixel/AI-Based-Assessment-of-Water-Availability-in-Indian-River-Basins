# GW Water AI Analysis Package

This repository contains a reproducible analysis pipeline for basin-scale seasonal surface-water analysis using the `annualTimeseriesBasins.csv` dataset.

## Run in Google Colab

1. Upload this repository to GitHub.
2. Open `GW_Water_AI_Analysis.ipynb` in Colab.
3. Run the installation cell.
4. Upload the actual `annualTimeseriesBasins.csv`.
5. Run the notebook from top to bottom.
6. Publication-ready figures are written to `outputs/figures/`.
7. Tables are written to `outputs/tables/`.

## Main analyses

- Data cleaning and audit
- Exploratory seasonal water-area trends
- Correlation analysis
- Random Forest regression for wet-season water area
- Random 80/20 benchmark
- Unseen-basin validation
- Forward temporal validation
- Residual analysis
- Feature importance, permutation importance, and SHAP regression explanation
- K-Means basin clustering
- SHAP summary plot for Random Forest regression
- Optional LSTM forecasting
- Optional ARIMA(2,1,2) benchmarking

## Important reproducibility rule

No hypothetical values are embedded in the code. Metrics and plots are generated from the uploaded dataset.

The random split is retained only as a benchmark. For generalization claims, use the unseen-basin and temporal validation results.

## Target and predictors

Target:
`wet_ond_water_ha`

Predictors:
`area_ha`, `year`, `dry_fma_nodata_ha`, `dry_fma_water_ha`,
`wet_ond_nodata_ha`, `total_nodata_ha`, `prm_DnW_water_ha`

## Forecasting

The notebook uses the observed all-basin annual-mean series for forecasting instead of relying on a manually selected representative basin. This avoids presenting a single basin as if it were representative of the complete dataset.

## Outputs

`outputs/figures/`
- seasonal water trends
- correlation matrix
- observed vs predicted
- residual plots
- feature importance
- permutation importance
- K-Means clusters
- optional LSTM forecast
- optional ARIMA forecast

`outputs/tables/`
- dataset audit
- validation metrics
- feature importance
- K-Means assignments
