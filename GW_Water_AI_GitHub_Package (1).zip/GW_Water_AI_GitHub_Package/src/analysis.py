
from __future__ import annotations

import warnings
warnings.filterwarnings("ignore")

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.pipeline import Pipeline
from sklearn.inspection import permutation_importance

RANDOM_STATE = 42

REQUIRED_COLUMNS = [
    "HYBAS_ID", "area_ha", "year",
    "dry_fma_nodata_ha", "dry_fma_water_ha",
    "wet_ond_nodata_ha", "wet_ond_water_ha",
    "total_nodata_ha", "prm_DnW_water_ha"
]

RF_FEATURES = [
    "area_ha", "year",
    "dry_fma_nodata_ha", "dry_fma_water_ha",
    "wet_ond_nodata_ha", "total_nodata_ha",
    "prm_DnW_water_ha"
]
RF_TARGET = "wet_ond_water_ha"


def load_and_clean(csv_path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    df = df[REQUIRED_COLUMNS].copy()
    for c in REQUIRED_COLUMNS:
        if c != "HYBAS_ID":
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df["HYBAS_ID"] = df["HYBAS_ID"].astype(str)
    df["year"] = df["year"].astype("Int64")

    before = len(df)
    df = df.dropna(subset=REQUIRED_COLUMNS).copy()
    df = df.drop_duplicates().sort_values(["HYBAS_ID", "year"]).reset_index(drop=True)

    # Remove physically impossible negative area values.
    area_cols = [c for c in REQUIRED_COLUMNS if c.endswith("_ha")]
    bad = (df[area_cols] < 0).any(axis=1)
    df = df.loc[~bad].copy()

    df.attrs["rows_before_cleaning"] = before
    df.attrs["rows_after_cleaning"] = len(df)
    return df


def metrics(y_true, y_pred) -> dict:
    return {
        "R2": float(r2_score(y_true, y_pred)),
        "RMSE_ha": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAE_ha": float(mean_absolute_error(y_true, y_pred)),
        "Bias_ha": float(np.mean(np.asarray(y_pred) - np.asarray(y_true))),
    }


def fit_rf_random_split(df: pd.DataFrame):
    X = df[RF_FEATURES]
    y = df[RF_TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE
    )
    model = RandomForestRegressor(
        n_estimators=100,
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    return model, X_train, X_test, y_train, y_test, pred, metrics(y_test, pred)


def fit_rf_basin_holdout(df: pd.DataFrame):
    """Unseen-basin validation: no basin appears in both train and test."""
    X = df[RF_FEATURES]
    y = df[RF_TARGET]
    groups = df["HYBAS_ID"]

    splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=RANDOM_STATE)
    train_idx, test_idx = next(splitter.split(X, y, groups=groups))

    model = RandomForestRegressor(
        n_estimators=100,
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
    model.fit(X.iloc[train_idx], y.iloc[train_idx])
    pred = model.predict(X.iloc[test_idx])

    result = metrics(y.iloc[test_idx], pred)
    result["n_train_basins"] = int(groups.iloc[train_idx].nunique())
    result["n_test_basins"] = int(groups.iloc[test_idx].nunique())
    return model, train_idx, test_idx, pred, result


def fit_rf_temporal_holdout(df: pd.DataFrame, test_fraction=0.20):
    """Forward-in-time validation using the latest years as the test period."""
    years = np.sort(df["year"].dropna().unique())
    if len(years) < 5:
        raise ValueError("At least five distinct years are recommended for temporal validation.")

    cut_pos = max(1, int(np.floor(len(years) * (1 - test_fraction))))
    cut_pos = min(cut_pos, len(years) - 1)
    cutoff = years[cut_pos - 1]

    train = df[df["year"] <= cutoff]
    test = df[df["year"] > cutoff]

    model = RandomForestRegressor(
        n_estimators=100,
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
    model.fit(train[RF_FEATURES], train[RF_TARGET])
    pred = model.predict(test[RF_FEATURES])
    result = metrics(test[RF_TARGET], pred)
    result["train_end_year"] = int(cutoff)
    result["test_start_year"] = int(test["year"].min())
    result["test_end_year"] = int(test["year"].max())
    return model, train, test, pred, result


def plot_observed_predicted(y_true, y_pred, outpath, title):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(y_true, y_pred, s=22, alpha=0.65)
    lo = min(y_true.min(), y_pred.min())
    hi = max(y_true.max(), y_pred.max())
    ax.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1.5)
    ax.set_xlabel("Observed wet-season water area (ha)")
    ax.set_ylabel("Predicted wet-season water area (ha)")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_residuals(y_true, y_pred, outpath, title):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    residual = y_pred - y_true
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(y_pred, residual, s=22, alpha=0.65)
    ax.axhline(0, linestyle="--", linewidth=1.5)
    ax.set_xlabel("Predicted wet-season water area (ha)")
    ax.set_ylabel("Residual (predicted − observed) (ha)")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_temporal_predictions(test_df, y_pred, outpath, title):
    tmp = test_df[["year"]].copy()
    tmp["observed"] = test_df[RF_TARGET].to_numpy()
    tmp["predicted"] = y_pred
    agg = tmp.groupby("year", as_index=False)[["observed", "predicted"]].mean()

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(agg["year"], agg["observed"], marker="o", label="Observed")
    ax.plot(agg["year"], agg["predicted"], marker="s", label="Predicted")
    ax.set_xlabel("Year")
    ax.set_ylabel("Mean wet-season water area (ha)")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def feature_importance_table(model) -> pd.DataFrame:
    return pd.DataFrame({
        "feature": RF_FEATURES,
        "importance": model.feature_importances_
    }).sort_values("importance", ascending=False)


def plot_feature_importance(model, outpath, title="Random Forest feature importance"):
    imp = feature_importance_table(model).sort_values("importance")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(imp["feature"], imp["importance"])
    ax.set_xlabel("Mean decrease in impurity")
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def permutation_importance_table(model, X, y) -> pd.DataFrame:
    r = permutation_importance(
        model, X, y, n_repeats=10, random_state=RANDOM_STATE,
        scoring="neg_mean_absolute_error", n_jobs=-1
    )
    return pd.DataFrame({
        "feature": X.columns,
        "importance_mean": r.importances_mean,
        "importance_std": r.importances_std
    }).sort_values("importance_mean", ascending=False)


def plot_permutation_importance(model, X, y, outpath):
    imp = permutation_importance_table(model, X, y).sort_values("importance_mean")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(imp["feature"], imp["importance_mean"],
            xerr=imp["importance_std"])
    ax.set_xlabel("Permutation importance (negative MAE scoring)")
    ax.set_title("Permutation feature importance")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_all_basin_seasonal_trend(df, outpath):
    annual = df.groupby("year", as_index=False)[
        ["dry_fma_water_ha", "wet_ond_water_ha"]
    ].mean()
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(annual["year"], annual["dry_fma_water_ha"], marker="o",
            label="Dry season")
    ax.plot(annual["year"], annual["wet_ond_water_ha"], marker="s",
            label="Wet season")
    ax.set_xlabel("Year")
    ax.set_ylabel("Mean water area (ha)")
    ax.set_title("Observed seasonal surface-water dynamics across all basins")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_correlation(df, outpath):
    cols = [c for c in RF_FEATURES + [RF_TARGET] if c in df.columns]
    corr = df[cols].corr(numeric_only=True)
    fig, ax = plt.subplots(figsize=(9, 7))
    im = ax.imshow(corr, aspect="auto")
    ax.set_xticks(range(len(cols)), cols, rotation=60, ha="right")
    ax.set_yticks(range(len(cols)), cols)
    fig.colorbar(im, ax=ax, label="Pearson correlation")
    ax.set_title("Correlation matrix of model variables")
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def run_kmeans(df: pd.DataFrame, n_clusters=3):
    cols = ["dry_fma_water_ha", "wet_ond_water_ha", "prm_DnW_water_ha"]
    basin = df.groupby("HYBAS_ID")[cols].mean().dropna()
    scaler = StandardScaler()
    Z = scaler.fit_transform(basin)
    km = KMeans(n_clusters=n_clusters, random_state=RANDOM_STATE, n_init=20)
    labels = km.fit_predict(Z)
    result = basin.copy()
    result["cluster"] = labels
    return result, km, scaler


def plot_kmeans(result, outpath):
    fig, ax = plt.subplots(figsize=(8, 6))
    for cluster, g in result.groupby("cluster"):
        ax.scatter(g["dry_fma_water_ha"], g["wet_ond_water_ha"],
                   s=45, alpha=0.7, label=f"Cluster {cluster}")
    ax.set_xlabel("Mean dry-season water area (ha)")
    ax.set_ylabel("Mean wet-season water area (ha)")
    ax.set_title("Basin clustering based on seasonal water availability")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close(fig)


def prepare_lstm_series(df: pd.DataFrame):
    """All-basin annual mean series; no hypothetical values are created."""
    s = (df.groupby("year", as_index=True)["dry_fma_water_ha"]
           .mean()
           .sort_index()
           .dropna())
    return s


def make_lstm_forecast(df: pd.DataFrame, forecast_years=6, n_steps=3,
                       epochs=100, outpath=None):
    """
    LSTM forecast on the observed all-basin annual-mean dry-season series.
    Forecast is generated only after fitting to the observed historical series.
    Requires TensorFlow.
    """
    import tensorflow as tf
    tf.random.set_seed(RANDOM_STATE)
    np.random.seed(RANDOM_STATE)

    series = prepare_lstm_series(df)
    if len(series) <= n_steps + 2:
        raise ValueError("Not enough annual observations for LSTM forecasting.")

    values = series.values.reshape(-1, 1)
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(values)

    X, y = [], []
    for i in range(n_steps, len(scaled)):
        X.append(scaled[i-n_steps:i, 0])
        y.append(scaled[i, 0])
    X = np.asarray(X).reshape(-1, n_steps, 1)
    y = np.asarray(y)

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(n_steps, 1)),
        tf.keras.layers.LSTM(50),
        tf.keras.layers.Dense(1)
    ])
    model.compile(optimizer="adam", loss="mse")
    model.fit(X, y, epochs=epochs, verbose=0)

    history = list(scaled[:, 0])
    for _ in range(forecast_years):
        x = np.asarray(history[-n_steps:]).reshape(1, n_steps, 1)
        history.append(float(model.predict(x, verbose=0)[0, 0]))

    future_scaled = np.asarray(history[-forecast_years:]).reshape(-1, 1)
    future = scaler.inverse_transform(future_scaled).ravel()
    years = np.arange(int(series.index.max()) + 1,
                      int(series.index.max()) + 1 + forecast_years)

    forecast_df = pd.DataFrame({
        "year": years,
        "forecast_dry_fma_water_ha": future
    })

    if outpath:
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.plot(series.index, series.values, marker="o", label="Observed")
        ax.plot(years, future, marker="s", linestyle="--", label="LSTM forecast")
        ax.set_xlabel("Year")
        ax.set_ylabel("Mean dry-season water area (ha)")
        ax.set_title("All-basin dry-season water-area forecast")
        ax.legend()
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(outpath, dpi=300, bbox_inches="tight")
        plt.close(fig)

    return model, series, forecast_df


def make_arima_forecast(df: pd.DataFrame, season="dry", forecast_years=6,
                        outpath=None):
    """ARIMA(2,1,2) benchmark on the all-basin annual mean observed series."""
    from statsmodels.tsa.arima.model import ARIMA

    col = "dry_fma_water_ha" if season == "dry" else "wet_ond_water_ha"
    series = (df.groupby("year")[col].mean().sort_index().dropna())

    if len(series) < 8:
        raise ValueError("Not enough annual observations for ARIMA.")

    model = ARIMA(series, order=(2, 1, 2))
    fitted = model.fit()
    forecast = fitted.get_forecast(steps=forecast_years)
    mean = forecast.predicted_mean
    ci = forecast.conf_int(alpha=0.05)

    years = np.arange(int(series.index.max()) + 1,
                      int(series.index.max()) + 1 + forecast_years)
    forecast_df = pd.DataFrame({
        "year": years,
        "forecast_ha": mean.values,
        "lower_95": ci.iloc[:, 0].values,
        "upper_95": ci.iloc[:, 1].values
    })

    if outpath:
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.plot(series.index, series.values, marker="o", label="Observed")
        ax.plot(years, mean.values, marker="s", linestyle="--", label="ARIMA forecast")
        ax.fill_between(years, ci.iloc[:, 0].values, ci.iloc[:, 1].values,
                        alpha=0.2, label="95% CI")
        ax.set_xlabel("Year")
        ax.set_ylabel(f"Mean {season}-season water area (ha)")
        ax.set_title(f"ARIMA(2,1,2) forecast — {season} season")
        ax.legend()
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(outpath, dpi=300, bbox_inches="tight")
        plt.close(fig)

    return fitted, series, forecast_df


def shap_summary_plot(model, X, outpath, max_display=10):
    """SHAP summary plot for the Random Forest regression model."""
    import shap
    explainer = shap.TreeExplainer(model)
    sample = X.copy()
    if len(sample) > 2000:
        sample = sample.sample(2000, random_state=RANDOM_STATE)
    shap_values = explainer.shap_values(sample)
    plt.figure(figsize=(9, 6))
    shap.summary_plot(
        shap_values, sample, show=False, max_display=max_display
    )
    plt.tight_layout()
    plt.savefig(outpath, dpi=300, bbox_inches="tight")
    plt.close()
