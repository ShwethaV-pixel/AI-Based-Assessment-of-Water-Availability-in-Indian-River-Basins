
from pathlib import Path
import pandas as pd

from .analysis import (
    load_and_clean, fit_rf_random_split, fit_rf_basin_holdout,
    fit_rf_temporal_holdout, plot_observed_predicted, plot_residuals,
    plot_temporal_predictions, plot_feature_importance,
    plot_permutation_importance, plot_all_basin_seasonal_trend,
    plot_correlation, run_kmeans, plot_kmeans
)

def run_core_analysis(csv_path, output_dir="outputs"):
    output_dir = Path(output_dir)
    fig_dir = output_dir / "figures"
    table_dir = output_dir / "tables"
    fig_dir.mkdir(parents=True, exist_ok=True)
    table_dir.mkdir(parents=True, exist_ok=True)

    df = load_and_clean(csv_path)

    # EDA
    plot_all_basin_seasonal_trend(df, fig_dir / "fig_seasonal_water_trends_all_basins.png")
    plot_correlation(df, fig_dir / "fig_correlation_matrix.png")

    # Original random split retained as a reproducibility benchmark.
    rf_rand, Xtr, Xte, ytr, yte, pred, rand_metrics = fit_rf_random_split(df)
    pd.DataFrame([rand_metrics]).to_csv(table_dir / "rf_random_split_metrics.csv", index=False)
    plot_observed_predicted(
        yte, pred, fig_dir / "fig_rf_observed_vs_predicted_random_split.png",
        "Random Forest: observed vs predicted wet-season water area"
    )
    plot_residuals(
        yte, pred, fig_dir / "fig_rf_residuals_random_split.png",
        "Random Forest residual analysis — random split"
    )
    plot_feature_importance(
        rf_rand, fig_dir / "fig_rf_feature_importance.png"
    )
    plot_permutation_importance(
        rf_rand, Xte, yte, fig_dir / "fig_rf_permutation_importance_test.png"
    )
    shap_summary_plot(
        rf_rand, Xte, fig_dir / "fig_rf_shap_summary.png"
    )

    # Corrected validation: unseen basins.
    rf_group, train_idx, test_idx, pred_group, group_metrics = fit_rf_basin_holdout(df)
    pd.DataFrame([group_metrics]).to_csv(table_dir / "rf_basin_holdout_metrics.csv", index=False)
    group_test = df.iloc[test_idx].copy()
    plot_observed_predicted(
        group_test["wet_ond_water_ha"], pred_group,
        fig_dir / "fig_rf_observed_vs_predicted_unseen_basins.png",
        "Random Forest: unseen-basin validation"
    )
    plot_residuals(
        group_test["wet_ond_water_ha"], pred_group,
        fig_dir / "fig_rf_residuals_unseen_basins.png",
        "Random Forest residual analysis — unseen basins"
    )

    # Corrected temporal validation.
    rf_time, train_time, test_time, pred_time, time_metrics = fit_rf_temporal_holdout(df)
    pd.DataFrame([time_metrics]).to_csv(table_dir / "rf_temporal_holdout_metrics.csv", index=False)
    plot_observed_predicted(
        test_time["wet_ond_water_ha"], pred_time,
        fig_dir / "fig_rf_observed_vs_predicted_temporal_holdout.png",
        "Random Forest: forward temporal validation"
    )
    plot_temporal_predictions(
        test_time, pred_time,
        fig_dir / "fig_rf_temporal_test_predictions.png",
        "Observed vs predicted wet-season water area in temporal test period"
    )

    # Save feature importance tables.
    pd.DataFrame({
        "feature": rf_rand.feature_names_in_,
        "importance": rf_rand.feature_importances_
    }).sort_values("importance", ascending=False).to_csv(
        table_dir / "rf_feature_importance.csv", index=False
    )

    # K-means clustering.
    cluster_result, km, scaler = run_kmeans(df, n_clusters=3)
    cluster_result.reset_index().to_csv(
        table_dir / "basin_kmeans_clusters.csv", index=False
    )
    plot_kmeans(cluster_result, fig_dir / "fig_kmeans_basin_clusters.png")

    # Dataset audit.
    audit = pd.DataFrame({
        "metric": [
            "rows_before_cleaning", "rows_after_cleaning",
            "number_of_basins", "min_year", "max_year"
        ],
        "value": [
            df.attrs.get("rows_before_cleaning", ""),
            df.attrs.get("rows_after_cleaning", len(df)),
            df["HYBAS_ID"].nunique(),
            int(df["year"].min()),
            int(df["year"].max())
        ]
    })
    audit.to_csv(table_dir / "dataset_audit.csv", index=False)

    return {
        "data": df,
        "random_split_metrics": rand_metrics,
        "unseen_basin_metrics": group_metrics,
        "temporal_metrics": time_metrics,
        "feature_importance": rf_rand,
        "cluster_result": cluster_result
    }
